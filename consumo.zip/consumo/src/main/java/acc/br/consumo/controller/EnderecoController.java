package acc.br.consumo.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import acc.br.consumo.model.Endereco;
import acc.br.consumo.service.EnderecoService;

@Controller
public class EnderecoController {

    private final EnderecoService enderecoService;

    public EnderecoController(EnderecoService enderecoService) {
        this.enderecoService = enderecoService;
    }

    @GetMapping("/")
    public String abrirPagina(Model model) {
        List<Endereco> enderecos = enderecoService.listarTodos();

        model.addAttribute("enderecos", enderecos);
        model.addAttribute("cep", "");

        return "enderecos";
    }

    @PostMapping("/consultar")
    public String consultarCep(String cep, Model model) {
        Endereco endereco = enderecoService.consultarESalvar(cep);

        if (endereco == null) {
            model.addAttribute("mensagemErro", "CEP não encontrado ou inválido.");
        } else {
            model.addAttribute("mensagemSucesso", "Endereço consultado e salvo com sucesso.");
        }

        List<Endereco> enderecos = enderecoService.listarTodos();

        model.addAttribute("enderecos", enderecos);
        model.addAttribute("cep", "");

        return "enderecos";
    }
}