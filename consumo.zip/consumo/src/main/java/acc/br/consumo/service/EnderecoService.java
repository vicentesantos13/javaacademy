package acc.br.consumo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import acc.br.consumo.interfaces.CepService;
import acc.br.consumo.model.Endereco;
import acc.br.consumo.repository.EnderecoRepository;

@Service
public class EnderecoService {

    private final CepService cepService;
    private final EnderecoRepository enderecoRepository;

    public EnderecoService(CepService cepService, EnderecoRepository enderecoRepository) {
        this.cepService = cepService;
        this.enderecoRepository = enderecoRepository;
    }

    public Endereco consultarESalvar(String cep) {
        if (cep == null) {
            return null;
        }

        String cepLimpo = cep.replace("-", "").trim();

        if (!cepLimpo.matches("\\d{8}")) {
            return null;
        }

        Endereco endereco = cepService.buscaEnderecoPorCep(cepLimpo);

        if (endereco == null || Boolean.TRUE.equals(endereco.getErro())) {
            return null;
        }

        return enderecoRepository.save(endereco);
    }
    public List<Endereco> listarTodos() {
        return enderecoRepository.findAll();
    }
}