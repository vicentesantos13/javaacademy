package acc.br.GenAi.runner;

import acc.br.GenAi.service.GeminiService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.swing.JOptionPane;

@Component
public class GeminiJOptionPaneRunner implements CommandLineRunner {

    private final GeminiService geminiService;

    public GeminiJOptionPaneRunner(GeminiService geminiService) {
        this.geminiService = geminiService;
    }

    @Override
    public void run(String... args) {
        boolean continuar = true;

        while (continuar) {
            try {
                String prompt = JOptionPane.showInputDialog(
                        null,
                        "Digite sua pergunta para o Gemini:",
                        "Mini Chatbot Gemini",
                        JOptionPane.QUESTION_MESSAGE
                );

                if (prompt == null) {
                    continuar = confirmarFinalizacao();
                    continue;
                }

                if (prompt.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(
                            null,
                            "Digite uma pergunta antes de enviar.",
                            "Aviso",
                            JOptionPane.WARNING_MESSAGE
                    );
                    continue;
                }

                String resposta = geminiService.sendMessage(prompt);

                JOptionPane.showMessageDialog(
                        null,
                        resposta,
                        "Resposta do Gemini",
                        JOptionPane.INFORMATION_MESSAGE
                );

                continuar = perguntarSeDesejaContinuar();

            } catch (Exception error) {
                JOptionPane.showMessageDialog(
                        null,
                        "Erro ao consultar o Gemini: " + error.getMessage(),
                        "Erro",
                        JOptionPane.ERROR_MESSAGE
                );

                continuar = perguntarSeDesejaContinuar();
            }
        }

        JOptionPane.showMessageDialog(
                null,
                "Chat finalizado.",
                "Mini Chatbot Gemini",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    private boolean perguntarSeDesejaContinuar() {
        int opcao = JOptionPane.showConfirmDialog(
                null,
                "Deseja fazer outra pergunta?",
                "Continuar?",
                JOptionPane.YES_NO_OPTION
        );

        return opcao == JOptionPane.YES_OPTION;
    }

    private boolean confirmarFinalizacao() {
        int opcao = JOptionPane.showConfirmDialog(
                null,
                "Deseja finalizar o chat?",
                "Finalizar?",
                JOptionPane.YES_NO_OPTION
        );

        return opcao != JOptionPane.YES_OPTION;
    }
}