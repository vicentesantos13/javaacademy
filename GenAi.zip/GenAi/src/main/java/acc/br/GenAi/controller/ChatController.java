package acc.br.GenAi.controller;

import acc.br.GenAi.model.ChatMessage;
import acc.br.GenAi.service.GeminiService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/chat")
public class ChatController {

    private final GeminiService geminiService;

    public ChatController(GeminiService geminiService) {
        this.geminiService = geminiService;
    }

    @GetMapping
    public String chat(@RequestParam String prompt) {
        return geminiService.sendMessage(prompt);
    }

    @GetMapping("/history")
    public List<ChatMessage> history() {
        return geminiService.listHistory();
    }
}