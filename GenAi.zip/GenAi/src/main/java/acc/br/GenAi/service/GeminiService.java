package acc.br.GenAi.service;

import acc.br.GenAi.model.ChatMessage;
import acc.br.GenAi.repository.ChatMessageRepository;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GeminiService {

    private final ChatClient chatClient;
    private final ChatMessageRepository repository;

    public GeminiService(ChatClient.Builder builder, ChatMessageRepository repository) {
        this.chatClient = builder.build();
        this.repository = repository;
    }

    public String sendMessage(String prompt) {
        if (prompt == null || prompt.trim().isEmpty()) {
            throw new IllegalArgumentException("A pergunta não pode estar vazia.");
        }

        String response = chatClient.prompt()
                .user(prompt)
                .call()
                .content();

        ChatMessage chatMessage = new ChatMessage(prompt, response);
        repository.save(chatMessage);

        return response;
    }

    public List<ChatMessage> listHistory() {
        return repository.findAll();
    }
}