package acc.br.aluno.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import acc.br.aluno.model.Aluno;

public interface AlunoRepository extends JpaRepository<Aluno, Integer> {
}