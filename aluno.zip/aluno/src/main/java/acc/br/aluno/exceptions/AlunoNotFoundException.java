package acc.br.aluno.exceptions;


public class AlunoNotFoundException extends RuntimeException {

    public AlunoNotFoundException(Integer id) {
        super("Aluno não encontrado com ID: " + id);
    }
}