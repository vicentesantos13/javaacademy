package acc.br.aluno.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import acc.br.aluno.model.Aluno;
import acc.br.aluno.service.AlunoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

@RestController
@Tag(name = "Aluno", description = "Endpoints para gerenciamento de alunos")
public class AlunoController {

    private final AlunoService alunoService;

    public AlunoController(AlunoService alunoService) {
        this.alunoService = alunoService;
    }

    @Operation(summary = "Listar todos os alunos")
    @GetMapping("/aluno")
    public List<Aluno> listarTodos() {
        return alunoService.listarTodos();
    }

    @Operation(summary = "Buscar aluno por ID")
    @GetMapping("/aluno/{id}")
    public Aluno buscarPorId(@PathVariable Integer id) {
        return alunoService.buscarPorId(id);
    }

    @Operation(summary = "Cadastrar novo aluno")
    @PostMapping("/aluno")
    public Aluno salvar(@RequestBody Aluno aluno) {
        return alunoService.salvar(aluno);
    }

    @Operation(summary = "Atualizar aluno existente")
    @PutMapping("/aluno/{id}")
    public Aluno atualizar(@PathVariable Integer id, @RequestBody Aluno aluno) {
        return alunoService.atualizar(id, aluno);
    }

    @Operation(summary = "Deletar aluno por ID")
    @DeleteMapping("/aluno/{id}")
    public void deletar(@PathVariable Integer id) {
        alunoService.deletar(id);
    }
}