package acc.br.aluno.service;

import java.util.List;

import org.springframework.stereotype.Service;

import acc.br.aluno.model.Aluno;
import acc.br.aluno.repository.AlunoRepository;
import acc.br.aluno.exceptions.AlunoNotFoundException;
@Service
public class AlunoService {

    private final AlunoRepository alunoRepository;

    public AlunoService(AlunoRepository alunoRepository) {
        this.alunoRepository = alunoRepository;
    }

    public List<Aluno> listarTodos() {
        return alunoRepository.findAll();
    }

    public Aluno buscarPorId(Integer id) {
        return alunoRepository.findById(id)
                .orElseThrow(() -> new AlunoNotFoundException(id));
    }

    public Aluno salvar(Aluno aluno) {
        return alunoRepository.save(aluno);
    }

    public Aluno atualizar(Integer id, Aluno alunoAtualizado) {
        Aluno alunoExistente = buscarPorId(id);

        alunoExistente.setNome(alunoAtualizado.getNome());
        alunoExistente.setEmail(alunoAtualizado.getEmail());
        alunoExistente.setCpf(alunoAtualizado.getCpf());

        return alunoRepository.save(alunoExistente);
    }

    public void deletar(Integer id) {
        Aluno aluno = buscarPorId(id);
        alunoRepository.delete(aluno);
    }
}