package exercicios.atividade2;

import java.util.Scanner;

public class Calculator {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int option;
		
		do {
			displayMenu();
			
			System.out.print("Escolha uma opção:");
			
			option = sc.nextInt();
			
			switch(option) {
			case 1 -> performAddition(sc);
			case 2 -> performSubtraction(sc);
			case 3 -> performMultiplication(sc);
			case 4 -> performDivision(sc);
			case 0 -> System.out.println("Encerrando calculadora...");
			default -> System.out.println("Opção inválida. Tente novamente.");

			}
			
			System.out.println();
		} while (option !=0);
		
		sc.close();
	}
	
	private static void displayMenu() {
        System.out.println("===== CALCULADORA =====");
        System.out.println("1 - Somar");
        System.out.println("2 - Subtrair");
        System.out.println("3 - Multiplicar");
        System.out.println("4 - Dividir");
        System.out.println("0 - Sair");
    }
	
	private static void performAddition(Scanner scanner) {
        double firstNumber = readNumber(scanner, "Digite o primeiro número: ");
        double secondNumber = readNumber(scanner, "Digite o segundo número: ");

        double result = add(firstNumber, secondNumber);

        System.out.println("Resultado da soma: " + result);
    }
	
	private static void performSubtraction(Scanner scanner) {
        double firstNumber = readNumber(scanner, "Digite o primeiro número: ");
        double secondNumber = readNumber(scanner, "Digite o segundo número: ");

        double result = subtract(firstNumber, secondNumber);

        System.out.println("Resultado da subtração: " + result);
    }
	
	private static void performMultiplication(Scanner scanner) {
        double firstNumber = readNumber(scanner, "Digite o primeiro número: ");
        double secondNumber = readNumber(scanner, "Digite o segundo número: ");

        double result = multiply(firstNumber, secondNumber);

        System.out.println("Resultado da multiplicação: " + result);
    }

    private static void performDivision(Scanner scanner) {
        double firstNumber = readNumber(scanner, "Digite o primeiro número: ");
        double secondNumber = readNumber(scanner, "Digite o segundo número: ");

        if (secondNumber == 0) {
            System.out.println("Erro: não é possível dividir por zero.");
            return;
        }

        double result = divide(firstNumber, secondNumber);

        System.out.println("Resultado da divisão: " + result);
    }

    private static double readNumber(Scanner scanner, String message) {
        System.out.print(message);
        return scanner.nextDouble();
    }

    private static double add(double firstNumber, double secondNumber) {
        return firstNumber + secondNumber;
    }

    private static double subtract(double firstNumber, double secondNumber) {
        return firstNumber - secondNumber;
    }

    private static double multiply(double firstNumber, double secondNumber) {
        return firstNumber * secondNumber;
    }

    private static double divide(double firstNumber, double secondNumber) {
        return firstNumber / secondNumber;
    }
		
		
		
}
