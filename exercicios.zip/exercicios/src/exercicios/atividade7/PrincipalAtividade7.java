package exercicios.atividade7;

public class PrincipalAtividade7 {
	public static void main(String[] args) {
        Casa casa = new Casa("Rua das Flores, 100", 3);
        Arvore arvore = new Arvore("Ipê", 4.5);
        Carro carro = new Carro("BMW Z4", "Vermelho");
        Joao joao = new Joao("João", 35);

        casa.setArvore(arvore);
        joao.morarEm(casa);
        joao.comprarCarro(carro);

        System.out.println();

        casa.receberSombraDaArvore();
        arvore.fazerSombra(casa);

        System.out.println();

        carro.dirigir();

        System.out.println();

        joao.entrarNoCarro();
        joao.dirigirCarro();

        System.out.println();

        joao.estacionarCarroNaCasa();
        joao.sairDoCarro();

        System.out.println();

        casa.exibirInformacoes();
    }
}
