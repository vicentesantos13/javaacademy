package exercicios.atividade7;

public class Arvore {
	private String tipo;
    private double altura;

    public Arvore(String tipo, double altura) {
        this.tipo = tipo;
        this.altura = altura;
    }

    public String getTipo() {
        return tipo;
    }

    public double getAltura() {
        return altura;
    }

    public void fazerSombra(Casa casa) {
        System.out.println("A árvore " + tipo + " está fazendo sombra na casa localizada em " + casa.getEndereco() + ".");
    }

    public void crescer() {
        altura += 0.5;
        System.out.println("A árvore cresceu. Altura atual: " + altura + " metros.");
    }
}
