package exercicios.atividade7;

public class Joao {
	 private String nome;
	    private int idade;
	    private Casa casa;
	    private Carro carro;

	    public Joao(String nome, int idade) {
	        this.nome = nome;
	        this.idade = idade;
	    }

	    public String getNome() {
	        return nome;
	    }

	    public int getIdade() {
	        return idade;
	    }

	    public void morarEm(Casa casa) {
	        this.casa = casa;
	        System.out.println(nome + " mora na casa localizada em " + casa.getEndereco() + ".");
	    }

	    public void comprarCarro(Carro carro) {
	        this.carro = carro;
	        System.out.println(nome + " comprou o carro " + carro.getModelo() + ".");
	    }

	    public void entrarNoCarro() {
	        if (carro == null) {
	            System.out.println(nome + " não possui carro.");
	        } else {
	            carro.entrarMotorista(this);
	        }
	    }

	    public void sairDoCarro() {
	        if (carro == null) {
	            System.out.println(nome + " não possui carro.");
	        } else {
	            carro.sairMotorista();
	        }
	    }

	    public void dirigirCarro() {
	        if (carro == null) {
	            System.out.println(nome + " não possui carro para dirigir.");
	        } else {
	            carro.ligar();
	            carro.dirigir();
	        }
	    }

	    public void estacionarCarroNaCasa() {
	        if (casa == null) {
	            System.out.println(nome + " não possui casa para estacionar.");
	        } else if (carro == null) {
	            System.out.println(nome + " não possui carro para estacionar.");
	        } else {
	            carro.desligar();
	            casa.guardarCarroNaGaragem(carro);
	        }
	    }
}
