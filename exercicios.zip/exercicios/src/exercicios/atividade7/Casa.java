package exercicios.atividade7;

public class Casa {
	 private String endereco;
	    private int quantidadeQuartos;
	    private Arvore arvore;
	    private Carro carroNaGaragem;

	    public Casa(String endereco, int quantidadeQuartos) {
	        this.endereco = endereco;
	        this.quantidadeQuartos = quantidadeQuartos;
	    }

	    public String getEndereco() {
	        return endereco;
	    }

	    public int getQuantidadeQuartos() {
	        return quantidadeQuartos;
	    }

	    public Arvore getArvore() {
	        return arvore;
	    }

	    public Carro getCarroNaGaragem() {
	        return carroNaGaragem;
	    }

	    public void setArvore(Arvore arvore) {
	        this.arvore = arvore;
	    }

	    public void guardarCarroNaGaragem(Carro carro) {
	        this.carroNaGaragem = carro;
	        System.out.println("O carro " + carro.getModelo() + " foi guardado na garagem da casa.");
	    }

	    public void retirarCarroDaGaragem() {
	        if (carroNaGaragem == null) {
	            System.out.println("Não há carro na garagem.");
	        } else {
	            System.out.println("O carro " + carroNaGaragem.getModelo() + " saiu da garagem.");
	            carroNaGaragem = null;
	        }
	    }

	    public void receberSombraDaArvore() {
	        if (arvore != null) {
	            System.out.println("A casa está recebendo sombra da árvore " + arvore.getTipo() + ".");
	        } else {
	            System.out.println("A casa não possui árvore para fazer sombra.");
	        }
	    }

	    public void exibirInformacoes() {
	        System.out.println("Casa localizada em: " + endereco);
	        System.out.println("Quantidade de quartos: " + quantidadeQuartos);

	        if (arvore != null) {
	            System.out.println("Árvore no terreno: " + arvore.getTipo());
	        }

	        if (carroNaGaragem != null) {
	            System.out.println("Carro na garagem: " + carroNaGaragem.getModelo());
	        }
	    }
}
