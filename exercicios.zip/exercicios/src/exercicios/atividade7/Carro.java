package exercicios.atividade7;

public class Carro {

    private String modelo;
    private String cor;
    private boolean ligado;
    private Joao motorista;

    public Carro(String modelo, String cor) {
        this.modelo = modelo;
        this.cor = cor;
        this.ligado = false;
    }

    public String getModelo() {
        return modelo;
    }

    public String getCor() {
        return cor;
    }

    public boolean isLigado() {
        return ligado;
    }

    public Joao getMotorista() {
        return motorista;
    }

    public void entrarMotorista(Joao joao) {
        this.motorista = joao;
        System.out.println(joao.getNome() + " entrou no carro " + modelo + ".");
    }

    public void sairMotorista() {
        if (motorista == null) {
            System.out.println("Não há motorista dentro do carro.");
        } else {
            System.out.println(motorista.getNome() + " saiu do carro " + modelo + ".");
            motorista = null;
        }
    }

    public void ligar() {
        if (motorista == null) {
            System.out.println("O carro " + modelo + " não pode ligar sem motorista.");
        } else {
            ligado = true;
            System.out.println("O carro " + modelo + " foi ligado por " + motorista.getNome() + ".");
        }
    }

    public void dirigir() {
        if (motorista == null) {
            System.out.println("O carro " + modelo + " não pode dirigir porque João não está dentro.");
        } else if (!ligado) {
            System.out.println("O carro " + modelo + " precisa estar ligado para dirigir.");
        } else {
            System.out.println(motorista.getNome() + " está dirigindo o carro " + modelo + ".");
        }
    }

    public void desligar() {
        ligado = false;
        System.out.println("O carro " + modelo + " foi desligado.");
    }
}