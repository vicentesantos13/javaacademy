package exercicios.atividade5;

public class PrincipalAnimais {
	public static void main (String[] args) {
		Gato gato = new Gato("Bichano", 7);
		Dog dog = new Dog("Rex",13);
		
		gato.emitirSom();
		dog.emitirSom();
	}
}
