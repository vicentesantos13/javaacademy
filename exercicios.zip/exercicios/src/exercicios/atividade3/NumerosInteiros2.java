package exercicios.atividade3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.List;

public class NumerosInteiros2 {

	   public static void main(String[] args) {
	        Scanner input = new Scanner(System.in);
	        //iniciando variaveis:
	        int saoPares = 0;
	        ArrayList<Integer> numerosPares = new ArrayList<>();
	        
	        //lendo a Quantidade de entrada:
	        System.out.println();
	        System.out.print("Quantos números você deseja digitar: ");
	        int quantidadeDeNumeros = input.nextInt();
	        
	        //Criando vetor recebendo a entrada:
	        int[] numeros = new int[quantidadeDeNumeros];
	        
	        //criando la�o for para armazenar as posi��es e armazenar a quantidade de pares:
	        for (int i = 0; i < numeros.length; i++) {
	            System.out.printf("Entre com a posição %d: ", i + 1);
	            numeros[i] = input.nextInt();
	            
	            boolean ehPar = numeros[i] % 2 == 0;
	            
	            saoPares += ehPar ? 1 : 0;
	            
	            numerosPares.addAll(ehPar ? List.of(numeros[i]) : List.of());
	        }
	        
	        String mensagemNumerosDigitados = numeros.length == 1
	                ? "O número digitado é: " + Arrays.toString(numeros)
	                : "Os números digitados são: " + Arrays.toString(numeros);

	        System.out.println(mensagemNumerosDigitados);

	        String mensagemQuantidadePares = saoPares == 1
	                ? "A quantidade de números pares é " + numerosPares + "."
	                : "Desses números, apenas " + saoPares + " são pares.";

	        String mensagemNumerosPares = saoPares == 1
	                ? numerosPares + " é um número par."
	                : "Os números pares são: " + numerosPares;

	        System.out.println(mensagemQuantidadePares);
	        System.out.println(mensagemNumerosPares);
	        
	       

	        input.close();
	    }
}
