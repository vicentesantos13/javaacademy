package exercicios.atividade6;

public class Carro {

    private String modelo;
    private boolean ligado;
    private boolean emMovimento;

    public Carro(String modelo) {
        this.modelo = modelo;
        this.ligado = false;
        this.emMovimento = false;
    }

    public String getModelo() {
        return modelo;
    }

    public boolean isLigado() {
        return ligado;
    }

    public boolean isEmMovimento() {
        return emMovimento;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void ligar() {
        if (ligado) {
            System.out.println(modelo + " já está ligado.");
        } else {
            ligado = true;
            System.out.println(modelo + " foi ligado.");
        }
    }

    public void desligar() {
        if (emMovimento) {
            System.out.println(modelo + " não pode ser desligado enquanto está em movimento.");
        } else if (!ligado) {
            System.out.println(modelo + " já está desligado.");
        } else {
            ligado = false;
            System.out.println(modelo + " foi desligado.");
        }
    }

    public void movimentar() {
        if (ligado) {
            emMovimento = true;
            System.out.println(modelo + " está em movimento.");
        } else {
            System.out.println(modelo + " não pode se movimentar porque está desligado.");
        }
    }

    public void parar() {
        if (emMovimento) {
            emMovimento = false;
            System.out.println(modelo + " parou.");
        } else {
            System.out.println(modelo + " já está parado.");
        }
    }

    public void buzinar() {
        if (emMovimento) {
            System.out.println(modelo + " buzinou: BEEP BEEP!");
        } else {
            System.out.println(modelo + " não pode buzinar porque não está em movimento.");
        }
    }
}
