package exercicios.atividade6;

public class CarroPrincipal {
	public static void main(String[] args) {
		Carro carro = new Carro("Fiat Uno");

		carro.buzinar();
		carro.movimentar();

		carro.ligar();
		carro.movimentar();
		carro.buzinar();

		carro.parar();
		carro.buzinar();

		carro.desligar();
	}
}
