package exercicios.atividade1;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.Scanner;


public class Stadium {
	private static final double PRECO_CLASSE_A = 50.00;
	private static final double PRECO_CLASSE_B = 30.00;
	private static final double PRECO_CLASSE_C = 20.00;
	
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

	    int quantityClasseA = readQuantity(scanner, "Classe A");
	    int quantityClasseB = readQuantity(scanner, "Classe B");
	    int quantityClasseC = readQuantity(scanner, "Classe C");

	    double incomeClasseA = calculateIncome(quantityClasseA, PRECO_CLASSE_A);
	    double incomeClasseB = calculateIncome(quantityClasseB, PRECO_CLASSE_B);
	    double incomeClasseC = calculateIncome(quantityClasseC, PRECO_CLASSE_C);

	    double incomeTotal = incomeClasseA + incomeClasseB + incomeClasseC;

	     exibirResultado(incomeClasseA, incomeClasseB, incomeClasseC, incomeTotal);

	    scanner.close();
	}

	private static int readQuantity(Scanner scanner, String className) {
		int quantity;

	    while (true) {
	    	System.out.print("Informe a quantidade de bilhetes vendidos da " + className + ": ");

	        if (scanner.hasNextInt()) {
	        	quantity = scanner.nextInt();

	            if (quantity >= 0) {
	            	return quantity;
	            }

	            System.out.println("Erro: a quantidade não pode ser negativa.");
	            } else {
	                System.out.println("Erro: digite apenas números inteiros.");
	                scanner.next();
	            }
	        }
	    }

	private static double calculateIncome (int quantity, double price) {
		return quantity * price;
	}

	    private static void exibirResultado(
	            double rendaClasseA,
	            double rendaClasseB,
	            double rendaClasseC,
	            double rendaTotal
	    ) {
	        NumberFormat formatoMoeda = NumberFormat.getCurrencyInstance( Locale.of("pt", "BR"));

	        System.out.println();
	        System.out.println("===== RELATÓRIO DE RENDA DO ESTÁDIO =====");
	        System.out.println("Renda da Classe A: " + formatoMoeda.format(rendaClasseA));
	        System.out.println("Renda da Classe B: " + formatoMoeda.format(rendaClasseB));
	        System.out.println("Renda da Classe C: " + formatoMoeda.format(rendaClasseC));
	        System.out.println("-----------------------------------------");
	        System.out.println("Renda total: " + formatoMoeda.format(rendaTotal));
	    }
	}
