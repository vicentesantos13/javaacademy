package exercicios.atividade4;

import java.util.Scanner;

public class LocalizaNumero {
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        int[] vetor = {1, 3, 5, 8, 9, 10};

	        System.out.print("Digite o número que deseja procurar no vetor: ");
	        int numero = scanner.nextInt();

	        boolean achou = false;
	        int posicao = -1;

	        for (int i = 0; i < vetor.length; i++) {
	            if (vetor[i] == numero) {
	                achou = true;
	                posicao = i;
	                break;
	            }
	        }

	        if (achou) {
	            System.out.println("Achei!");
	            System.out.printf(
	                    "Na posição %d está localizado o número %d.%n",
	                    posicao,
	                    vetor[posicao]
	            );
	        } else {
	            System.out.println("Número não encontrado no vetor.");
	        }

	        scanner.close();
	    }
}
