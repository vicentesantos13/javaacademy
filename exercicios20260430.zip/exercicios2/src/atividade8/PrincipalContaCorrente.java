package atividade8;

import java.time.LocalDate;

public class PrincipalContaCorrente {

    public static void main(String[] args) {

        try {
            Cliente cliente1 = new Cliente("João", "Silva", "123.456.789-00");
            Cliente cliente2 = new Cliente("Maria", "Souza", "987.654.321-00");

            ContaCorrente conta1 = new ContaCorrente(1001, cliente1, 500.00, LocalDate.now());
            ContaCorrente conta2 = new ContaCorrente(1002, cliente2, 300.00, LocalDate.now());

            System.out.println("========== CONTAS CRIADAS ==========");
            System.out.println("Conta 1 criada para o cliente: " + conta1.getCliente().getNomeCompleto());
            System.out.println("Conta 2 criada para o cliente: " + conta2.getCliente().getNomeCompleto());
            System.out.println();

            System.out.println("========== CONSULTA INICIAL ==========");
            conta1.exibirSaldo();
            conta2.exibirSaldo();

            System.out.println("Executando depósito de R$ 200,00 na conta 1...");
            conta1.depositar(200.00);

            System.out.println("Executando saque de R$ 100,00 na conta 1...");
            conta1.sacar(100.00);

            System.out.println("Executando transferência de R$ 250,00 da conta 1 para a conta 2...");
            conta1.transferir(conta2, 250.00);

            System.out.println("Tentando transferir R$ 1000,00 da conta 1 para a conta 2...");
            conta1.transferir(conta2, 1000.00);

            System.out.println("========== EXTRATOS FINAIS ==========");
            conta1.exibirExtrato();
            conta2.exibirExtrato();

        } catch (IllegalArgumentException error) {
            System.out.println("Operação não realizada.");
            System.out.println("Motivo: " + error.getMessage());
        } catch (Exception error) {
            System.out.println("Erro inesperado.");
            System.out.println("Detalhes: " + error.getMessage());
        }
    }
}