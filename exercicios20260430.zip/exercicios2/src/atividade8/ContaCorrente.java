package atividade8;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ContaCorrente {

    private int numero;
    private Cliente cliente;
    private double saldo;
    private LocalDate data;
    private List<String> extrato;

    public ContaCorrente(int numero, Cliente cliente, double saldoInicial, LocalDate data) {
        if (saldoInicial < 0) {
            throw new IllegalArgumentException("O saldo inicial não pode ser negativo.");
        }

        this.numero = numero;
        this.cliente = cliente;
        this.saldo = saldoInicial;
        this.data = data;
        this.extrato = new ArrayList<>();

        extrato.add("Abertura da conta | Saldo inicial: R$ " + formatarValor(saldoInicial));
    }

    public int getNumero() {
        return numero;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public double getSaldo() {
        return saldo;
    }

    public LocalDate getData() {
        return data;
    }

    public void depositar(double valor) {
        if (valor <= 0) {
            throw new IllegalArgumentException("O valor do depósito deve ser maior que zero.");
        }

        double saldoAnterior = saldo;
        saldo += valor;

        extrato.add("Depósito | Valor: R$ " + formatarValor(valor)
                + " | Saldo anterior: R$ " + formatarValor(saldoAnterior)
                + " | Saldo atual: R$ " + formatarValor(saldo));

        System.out.println("========== DEPÓSITO ==========");
        System.out.println("Conta: " + numero);
        System.out.println("Cliente: " + cliente.getNomeCompleto());
        System.out.println("Valor depositado: R$ " + formatarValor(valor));
        System.out.println("Saldo anterior: R$ " + formatarValor(saldoAnterior));
        System.out.println("Saldo atual: R$ " + formatarValor(saldo));
        System.out.println();
    }

    public void sacar(double valor) {
        if (valor <= 0) {
            throw new IllegalArgumentException("O valor do saque deve ser maior que zero.");
        }

        if (valor > saldo) {
            throw new IllegalArgumentException(
                    "Saque cancelado. Saldo insuficiente na conta " + numero + "."
            );
        }

        double saldoAnterior = saldo;
        saldo -= valor;

        extrato.add("Saque | Valor: R$ " + formatarValor(valor)
                + " | Saldo anterior: R$ " + formatarValor(saldoAnterior)
                + " | Saldo atual: R$ " + formatarValor(saldo));

        System.out.println("========== SAQUE ==========");
        System.out.println("Conta: " + numero);
        System.out.println("Cliente: " + cliente.getNomeCompleto());
        System.out.println("Valor sacado: R$ " + formatarValor(valor));
        System.out.println("Saldo anterior: R$ " + formatarValor(saldoAnterior));
        System.out.println("Saldo atual: R$ " + formatarValor(saldo));
        System.out.println();
    }

    public void transferir(ContaCorrente contaDestino, double valor) {
        if (contaDestino == null) {
            throw new IllegalArgumentException("A conta de destino não pode ser nula.");
        }

        if (valor <= 0) {
            throw new IllegalArgumentException("O valor da transferência deve ser maior que zero.");
        }

        System.out.println("========== TRANSFERÊNCIA ==========");
        System.out.println("Conta de origem: " + numero + " - " + cliente.getNomeCompleto());
        System.out.println("Conta de destino: " + contaDestino.getNumero() + " - " + contaDestino.getCliente().getNomeCompleto());
        System.out.println("Valor solicitado: R$ " + formatarValor(valor));

        if (valor > saldo) {
            System.out.println("Status: transferência cancelada.");
            System.out.println("Motivo: a conta de origem ficaria negativa.");
            System.out.println("Saldo disponível na origem: R$ " + formatarValor(saldo));
            System.out.println();

            extrato.add("Transferência cancelada | Valor solicitado: R$ " + formatarValor(valor)
                    + " | Motivo: saldo insuficiente");

            return;
        }

        double saldoAnteriorOrigem = this.saldo;
        double saldoAnteriorDestino = contaDestino.saldo;

        this.saldo -= valor;
        contaDestino.saldo += valor;

        this.extrato.add("Transferência enviada | Valor: R$ " + formatarValor(valor)
                + " | Destino: " + contaDestino.getCliente().getNomeCompleto()
                + " | Saldo anterior: R$ " + formatarValor(saldoAnteriorOrigem)
                + " | Saldo atual: R$ " + formatarValor(this.saldo));

        contaDestino.extrato.add("Transferência recebida | Valor: R$ " + formatarValor(valor)
                + " | Origem: " + this.cliente.getNomeCompleto()
                + " | Saldo anterior: R$ " + formatarValor(saldoAnteriorDestino)
                + " | Saldo atual: R$ " + formatarValor(contaDestino.saldo));

        System.out.println("Status: transferência realizada com sucesso.");
        System.out.println();
        System.out.println("Resumo da conta de origem:");
        System.out.println("Saldo anterior: R$ " + formatarValor(saldoAnteriorOrigem));
        System.out.println("Saldo atual: R$ " + formatarValor(this.saldo));
        System.out.println();
        System.out.println("Resumo da conta de destino:");
        System.out.println("Saldo anterior: R$ " + formatarValor(saldoAnteriorDestino));
        System.out.println("Saldo atual: R$ " + formatarValor(contaDestino.saldo));
        System.out.println();
    }

    public void exibirSaldo() {
        System.out.println("========== SALDO ==========");
        System.out.println("Conta: " + numero);
        System.out.println("Cliente: " + cliente.getNomeCompleto());
        System.out.println("Saldo atual: R$ " + formatarValor(saldo));
        System.out.println();
    }

    public void exibirExtrato() {
        System.out.println("========== EXTRATO ==========");
        System.out.println("Conta: " + numero);
        System.out.println("Cliente: " + cliente.getNomeCompleto());
        System.out.println("CPF: " + cliente.getCpf());
        System.out.println("Data de abertura: " + data);
        System.out.println("Saldo atual: R$ " + formatarValor(saldo));
        System.out.println("-----------------------------");

        for (String movimentacao : extrato) {
            System.out.println(movimentacao);
        }

        System.out.println();
    }

    private String formatarValor(double valor) {
        return String.format("%.2f", valor);
    }
}