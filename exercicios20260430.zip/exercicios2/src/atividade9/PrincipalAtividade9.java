package atividade9;

import java.util.Scanner;

public class PrincipalAtividade9 {

    private static final int QUANTIDADE_NOTAS = 3;
    private static final double NOTA_MINIMA = 0;
    private static final double NOTA_MAXIMA = 100;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("===== SISTEMA DE NOTAS DOS ALUNOS =====");

            int quantidadeAlunos = lerQuantidadeAlunos(scanner);
            Aluno[] alunos = new Aluno[quantidadeAlunos];

            for (int i = 0; i < alunos.length; i++) {
                System.out.println();
                System.out.println("Cadastro do aluno " + (i + 1));

                String nome = lerNome(scanner);
                double[] notas = lerNotas(scanner);

                alunos[i] = new Aluno(nome, notas);
            }

            System.out.println();
            exibirRelatorioIndividual(alunos);

            System.out.println();
            exibirEstatisticasDaTurma(alunos);

            System.out.println();
            exibirDistribuicaoDeResultados(alunos);

            System.out.println();
            exibirMelhoresAlunos(alunos);

        } catch (Exception erro) {
            System.out.println("Erro inesperado: " + erro.getMessage());
        } finally {
            scanner.close();
        }
    }

    private static int lerQuantidadeAlunos(Scanner scanner) {
        while (true) {
            try {
                System.out.print("Digite a quantidade de alunos: ");
                int quantidade = Integer.parseInt(scanner.nextLine());

                validar(quantidade > 0, "A quantidade de alunos deve ser maior que zero.");

                return quantidade;
            } catch (NumberFormatException erro) {
                System.out.println("Erro: digite um número inteiro válido.");
            } catch (IllegalArgumentException erro) {
                System.out.println("Erro: " + erro.getMessage());
            }
        }
    }

    private static String lerNome(Scanner scanner) {
        while (true) {
            try {
                System.out.print("Digite o nome do aluno: ");
                String nome = scanner.nextLine().trim();

                validar(nome.length() >= 3, "O nome deve ter no mínimo 3 caracteres.");

                return nome;
            } catch (IllegalArgumentException erro) {
                System.out.println("Erro: " + erro.getMessage());
            }
        }
    }

    private static double[] lerNotas(Scanner scanner) {
        double[] notas = new double[QUANTIDADE_NOTAS];

        for (int i = 0; i < notas.length; i++) {
            notas[i] = lerNota(scanner, i + 1);
        }

        return notas;
    }

    private static double lerNota(Scanner scanner, int numeroNota) {
        while (true) {
            try {
                System.out.print("Digite a nota (0 a 100) " + numeroNota + ": ");
                double nota = Double.parseDouble(scanner.nextLine());

                validar(
                        nota >= NOTA_MINIMA && nota <= NOTA_MAXIMA,
                        "A nota deve estar entre 0 e 100."
                );

                return nota;
            } catch (NumberFormatException erro) {
                System.out.println("Erro: digite uma nota válida.");
            } catch (IllegalArgumentException erro) {
                System.out.println("Erro: " + erro.getMessage());
            }
        }
    }

    private static void validar(boolean condicao, String mensagemErro) {
        switch (condicao ? 1 : 0) {
            case 1 -> {
            }
            default -> throw new IllegalArgumentException(mensagemErro);
        }
    }

    private static void exibirRelatorioIndividual(Aluno[] alunos) {
        System.out.println("===== 1. RELATÓRIO INDIVIDUAL =====");

        for (Aluno aluno : alunos) {
            aluno.exibirRelatorioIndividual();
        }
    }

    private static void exibirEstatisticasDaTurma(Aluno[] alunos) {
        double maiorMedia = alunos[0].getMedia();
        double menorMedia = alunos[0].getMedia();
        double somaMedias = 0;

        for (Aluno aluno : alunos) {
            maiorMedia = Math.max(maiorMedia, aluno.getMedia());
            menorMedia = Math.min(menorMedia, aluno.getMedia());
            somaMedias += aluno.getMedia();
        }

        double mediaGeral = somaMedias / alunos.length;

        System.out.println("===== 2. ESTATÍSTICAS DA TURMA =====");
        System.out.printf("Maior média: %.2f%n", maiorMedia);
        System.out.printf("Menor média: %.2f%n", menorMedia);
        System.out.printf("Média geral da turma: %.2f%n", mediaGeral);
    }

    private static void exibirDistribuicaoDeResultados(Aluno[] alunos) {
        int aprovados = 0;
        int recuperacao = 0;
        int reprovados = 0;

        for (Aluno aluno : alunos) {
            switch (aluno.getSituacao()) {
                case "APROVADO" -> aprovados++;
                case "RECUPERAÇÃO" -> recuperacao++;
                default -> reprovados++;
            }
        }

        System.out.println("===== 3. DISTRIBUIÇÃO DE RESULTADOS =====");
        System.out.println("Quantidade de alunos: " + alunos.length);
        System.out.println("Aprovados: " + aprovados);
        System.out.println("Recuperação: " + recuperacao);
        System.out.println("Reprovados: " + reprovados);
    }

    private static void exibirMelhoresAlunos(Aluno[] alunos) {
        double maiorMedia = alunos[0].getMedia();

        for (Aluno aluno : alunos) {
            maiorMedia = Math.max(maiorMedia, aluno.getMedia());
        }

        System.out.println("===== 4. MELHOR(ES) ALUNO(S) =====");
        System.out.printf("Maior média encontrada: %.2f%n", maiorMedia);
        System.out.println("Aluno(s) com a maior média:");

        for (Aluno aluno : alunos) {
            switch (aluno.getMedia() == maiorMedia ? 1 : 0) {
                case 1 -> System.out.printf("%s | Média: %.2f%n", aluno.getNome(), aluno.getMedia());
                default -> {
                }
            }
        }
    }
}