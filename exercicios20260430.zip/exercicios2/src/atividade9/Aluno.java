package atividade9;

import java.util.Arrays;

public class Aluno {

    private String nome;
    private double[] notas;
    private double media;
    private String situacao;

    public Aluno(String nome, double[] notas) {
        this.nome = nome;
        this.notas = notas;
        this.media = calcularMedia();
        this.situacao = definirSituacao();
    }

    public String getNome() {
        return nome;
    }

    public double[] getNotas() {
        return notas;
    }

    public double getMedia() {
        return media;
    }

    public String getSituacao() {
        return situacao;
    }

    private double calcularMedia() {
        double soma = 0;

        for (double nota : notas) {
            soma += nota;
        }

        return soma / notas.length;
    }

    private String definirSituacao() {
        int codigoSituacao = media >= 70 ? 1 : media >= 50 ? 2 : 3;

        return switch (codigoSituacao) {
            case 1 -> "APROVADO";
            case 2 -> "RECUPERAÇÃO";
            default -> "REPROVADO";
        };
    }

    public void exibirRelatorioIndividual() {
        System.out.printf(
                "%s | Notas: %s | Média: %.2f | %s%n",
                nome,
                Arrays.toString(notas),
                media,
                situacao
        );
    }
}