package atividade10;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Pedido {

    private int id;
    private Cliente cliente;
    private List<ItemPedido> itens;
    private StatusPedido status;
    private double descontoPercentual;
    private LocalDateTime dataCriacao;

    public Pedido(int id, Cliente cliente) {
        this.id = id;
        this.cliente = cliente;
        this.itens = new ArrayList<>();
        this.status = StatusPedido.CREATED;
        this.descontoPercentual = 0;
        this.dataCriacao = LocalDateTime.now();
    }

    public int getId() {
        return id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public List<ItemPedido> getItens() {
        return itens;
    }

    public StatusPedido getStatus() {
        return status;
    }

    public double getDescontoPercentual() {
        return descontoPercentual;
    }

    public void setStatus(StatusPedido status) {
        this.status = status;
    }

    public void adicionarItem(ItemPedido item) {
        itens.add(item);
    }

    public void aplicarDesconto(double descontoPercentual) {
        if (descontoPercentual < 0 || descontoPercentual > 50) {
            throw new IllegalArgumentException("O desconto deve estar entre 0% e 50%.");
        }

        this.descontoPercentual = descontoPercentual;
    }

    public double calcularTotalBruto() {
        double total = 0;

        for (ItemPedido item : itens) {
            total += item.getSubtotal();
        }

        return total;
    }

    public double calcularTotalComDesconto() {
        double totalBruto = calcularTotalBruto();
        return totalBruto - (totalBruto * descontoPercentual / 100);
    }

    public void exibirResumo() {
        System.out.println("========== PEDIDO " + id + " ==========");
        System.out.println("Cliente: " + cliente.getNome());
        System.out.println("Status: " + status);
        System.out.println("Data: " + dataCriacao);
        System.out.println("Itens:");

        for (ItemPedido item : itens) {
            item.exibir();
        }

        System.out.printf("Total bruto: R$ %.2f%n", calcularTotalBruto());
        System.out.printf("Desconto: %.2f%%%n", descontoPercentual);
        System.out.printf("Total final: R$ %.2f%n", calcularTotalComDesconto());
        System.out.println();
    }
}