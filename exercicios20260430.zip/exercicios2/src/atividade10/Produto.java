package atividade10;

public class Produto {

    private String sku;
    private String nome;
    private String categoria;
    private double preco;
    private int estoque;
    private int quantidadeVendida;

    public Produto(String sku, String nome, String categoria, double preco, int estoque) {
        this.sku = sku;
        this.nome = nome;
        this.categoria = categoria;
        this.preco = preco;
        this.estoque = estoque;
        this.quantidadeVendida = 0;
    }

    public String getSku() {
        return sku;
    }

    public String getNome() {
        return nome;
    }

    public String getCategoria() {
        return categoria;
    }

    public double getPreco() {
        return preco;
    }

    public int getEstoque() {
        return estoque;
    }

    public int getQuantidadeVendida() {
        return quantidadeVendida;
    }

    public void reservarEstoque(int quantidade) {
        if (quantidade <= 0) {
            throw new IllegalArgumentException("A quantidade deve ser maior que zero.");
        }

        if (quantidade > estoque) {
            throw new IllegalArgumentException("Estoque insuficiente para o produto: " + nome);
        }

        estoque -= quantidade;
    }

    public void liberarEstoque(int quantidade) {
        estoque += quantidade;
    }

    public void registrarVenda(int quantidade) {
        quantidadeVendida += quantidade;
    }

    public void exibir() {
        System.out.printf(
                "SKU: %s | Nome: %s | Categoria: %s | Preço: R$ %.2f | Estoque: %d%n",
                sku,
                nome,
                categoria,
                preco,
                estoque
        );
    }
}