package atividade10;

public class Cliente {

    private int id;
    private String nome;
    private String email;
    private int quantidadePedidos;

    public Cliente(int id, String nome, String email) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.quantidadePedidos = 0;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public int getQuantidadePedidos() {
        return quantidadePedidos;
    }

    public void registrarPedido() {
        quantidadePedidos++;
    }

    public void exibir() {
        System.out.printf(
                "ID: %d | Nome: %s | Email: %s | Pedidos: %d%n",
                id,
                nome,
                email,
                quantidadePedidos
        );
    }
}