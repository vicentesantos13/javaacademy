package atividade10;

public class ItemPedido {

    private Produto produto;
    private int quantidade;
    private double precoUnitario;

    public ItemPedido(Produto produto, int quantidade) {
        if (quantidade <= 0) {
            throw new IllegalArgumentException("A quantidade do item deve ser maior que zero.");
        }

        this.produto = produto;
        this.quantidade = quantidade;
        this.precoUnitario = produto.getPreco();
    }

    public Produto getProduto() {
        return produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public double getSubtotal() {
        return quantidade * precoUnitario;
    }

    public void exibir() {
        System.out.printf(
                "%s | Quantidade: %d | Preço unitário: R$ %.2f | Subtotal: R$ %.2f%n",
                produto.getNome(),
                quantidade,
                precoUnitario,
                getSubtotal()
        );
    }
}