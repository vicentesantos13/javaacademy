package atividade10;

public enum StatusPedido {
    CREATED,
    RESERVED,
    PAID,
    FAILED,
    CANCELLED
}