package atividade10;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class EcommerceService {

    private Map<String, Produto> produtos = new HashMap<>();
    private Map<Integer, Cliente> clientes = new HashMap<>();
    private Map<Integer, Pedido> pedidos = new HashMap<>();
    private int proximoClienteId = 1;
    private int proximoPedidoId = 1;

    public void adicionarProduto(String sku, String nome, String categoria, double preco, int estoque) {
        if (produtos.containsKey(sku)) {
            throw new IllegalArgumentException("Já existe um produto cadastrado com esse SKU.");
        }

        Produto produto = new Produto(sku, nome, categoria, preco, estoque);
        produtos.put(sku, produto);

        System.out.println("Produto cadastrado com sucesso.");
        produto.exibir();
        System.out.println();
    }

    public void listarProdutosPorSku() {
        System.out.println("========== PRODUTOS ORDENADOS POR SKU ==========");

        produtos.values()
                .stream()
                .sorted(Comparator.comparing(Produto::getSku))
                .forEach(Produto::exibir);

        System.out.println();
    }

    public void listarProdutosPorPreco() {
        System.out.println("========== PRODUTOS ORDENADOS POR PREÇO ==========");

        produtos.values()
                .stream()
                .sorted(Comparator.comparingDouble(Produto::getPreco))
                .forEach(Produto::exibir);

        System.out.println();
    }

    public void buscarProdutoPorSku(String sku) {
        Produto produto = buscarProdutoObrigatorio(sku);

        System.out.println("========== PRODUTO ENCONTRADO ==========");
        produto.exibir();
        System.out.println();
    }

    public void adicionarCliente(String nome, String email) {
        Cliente cliente = new Cliente(proximoClienteId, nome, email);
        clientes.put(proximoClienteId, cliente);
        proximoClienteId++;

        System.out.println("Cliente cadastrado com sucesso.");
        cliente.exibir();
        System.out.println();
    }

    public void listarClientes() {
        System.out.println("========== CLIENTES ==========");

        clientes.values().forEach(Cliente::exibir);

        System.out.println();
    }

    public int criarPedido(int clienteId, Map<String, Integer> itensSolicitados) {
        Cliente cliente = buscarClienteObrigatorio(clienteId);

        Pedido pedido = new Pedido(proximoPedidoId, cliente);

        for (Map.Entry<String, Integer> entrada : itensSolicitados.entrySet()) {
            Produto produto = buscarProdutoObrigatorio(entrada.getKey());
            ItemPedido item = new ItemPedido(produto, entrada.getValue());
            pedido.adicionarItem(item);
        }

        if (pedido.getItens().isEmpty()) {
            throw new IllegalArgumentException("O pedido precisa ter pelo menos um item.");
        }

        pedidos.put(proximoPedidoId, pedido);
        cliente.registrarPedido();

        System.out.println("Pedido criado com sucesso.");
        pedido.exibirResumo();

        proximoPedidoId++;
        return pedido.getId();
    }

    public void reservarEstoque(int pedidoId) {
        Pedido pedido = buscarPedidoObrigatorio(pedidoId);

        if (pedido.getStatus() != StatusPedido.CREATED) {
            throw new IllegalArgumentException("Só é possível reservar estoque de pedidos com status CREATED.");
        }

        for (ItemPedido item : pedido.getItens()) {
            item.getProduto().reservarEstoque(item.getQuantidade());
        }

        pedido.setStatus(StatusPedido.RESERVED);

        System.out.println("Estoque reservado com sucesso para o pedido " + pedidoId + ".");
        pedido.exibirResumo();
    }

    public void aplicarDesconto(int pedidoId, double descontoPercentual) {
        Pedido pedido = buscarPedidoObrigatorio(pedidoId);

        if (pedido.getStatus() == StatusPedido.PAID || pedido.getStatus() == StatusPedido.CANCELLED) {
            throw new IllegalArgumentException("Não é possível aplicar desconto em pedido pago ou cancelado.");
        }

        pedido.aplicarDesconto(descontoPercentual);

        System.out.println("Desconto aplicado com sucesso.");
        pedido.exibirResumo();
    }

    public void pagarPedido(int pedidoId, boolean pagamentoAprovado) {
        Pedido pedido = buscarPedidoObrigatorio(pedidoId);

        if (pedido.getStatus() != StatusPedido.RESERVED) {
            throw new IllegalArgumentException("O pedido precisa estar com status RESERVED antes do pagamento.");
        }

        if (pagamentoAprovado) {
            pedido.setStatus(StatusPedido.PAID);

            for (ItemPedido item : pedido.getItens()) {
                item.getProduto().registrarVenda(item.getQuantidade());
            }

            System.out.println("Pagamento aprovado. Pedido marcado como PAID.");
        } else {
            pedido.setStatus(StatusPedido.FAILED);

            for (ItemPedido item : pedido.getItens()) {
                item.getProduto().liberarEstoque(item.getQuantidade());
            }

            System.out.println("Pagamento recusado. Estoque liberado e pedido marcado como FAILED.");
        }

        pedido.exibirResumo();
    }

    public void cancelarPedido(int pedidoId) {
        Pedido pedido = buscarPedidoObrigatorio(pedidoId);

        if (pedido.getStatus() == StatusPedido.PAID) {
            throw new IllegalArgumentException("Não é possível cancelar um pedido já pago.");
        }

        if (pedido.getStatus() == StatusPedido.RESERVED) {
            for (ItemPedido item : pedido.getItens()) {
                item.getProduto().liberarEstoque(item.getQuantidade());
            }
        }

        pedido.setStatus(StatusPedido.CANCELLED);

        System.out.println("Pedido cancelado com sucesso.");
        pedido.exibirResumo();
    }

    public void listarPedidos() {
        System.out.println("========== PEDIDOS ==========");

        pedidos.values().forEach(Pedido::exibirResumo);
    }

    public void relatorioFaturamentoTotal() {
        double faturamento = pedidos.values()
                .stream()
                .filter(pedido -> pedido.getStatus() == StatusPedido.PAID)
                .mapToDouble(Pedido::calcularTotalComDesconto)
                .sum();

        System.out.println("========== FATURAMENTO TOTAL ==========");
        System.out.printf("Faturamento total de pedidos PAID: R$ %.2f%n%n", faturamento);
    }

    public void relatorioTopProdutosVendidos() {
        System.out.println("========== TOP 3 PRODUTOS MAIS VENDIDOS ==========");

        produtos.values()
                .stream()
                .sorted(Comparator.comparingInt(Produto::getQuantidadeVendida).reversed())
                .limit(3)
                .forEach(produto -> System.out.printf(
                        "%s | SKU: %s | Quantidade vendida: %d%n",
                        produto.getNome(),
                        produto.getSku(),
                        produto.getQuantidadeVendida()
                ));

        System.out.println();
    }

    public void relatorioFaturamentoPorCategoria() {
        Map<String, Double> faturamentoPorCategoria = new HashMap<>();

        for (Pedido pedido : pedidos.values()) {
            if (pedido.getStatus() == StatusPedido.PAID) {
                for (ItemPedido item : pedido.getItens()) {
                    String categoria = item.getProduto().getCategoria();
                    double valor = item.getSubtotal();

                    faturamentoPorCategoria.put(
                            categoria,
                            faturamentoPorCategoria.getOrDefault(categoria, 0.0) + valor
                    );
                }
            }
        }

        System.out.println("========== FATURAMENTO POR CATEGORIA ==========");

        faturamentoPorCategoria.forEach((categoria, valor) ->
                System.out.printf("%s: R$ %.2f%n", categoria, valor)
        );

        System.out.println();
    }

    public void relatorioClientesComMaisPedidos() {
        System.out.println("========== CLIENTES COM MAIS PEDIDOS ==========");

        clientes.values()
                .stream()
                .sorted(Comparator.comparingInt(Cliente::getQuantidadePedidos).reversed())
                .forEach(cliente -> System.out.printf(
                        "%s | ID: %d | Pedidos: %d%n",
                        cliente.getNome(),
                        cliente.getId(),
                        cliente.getQuantidadePedidos()
                ));

        System.out.println();
    }

    public void relatorioProdutosComEstoqueBaixo(int limite) {
        System.out.println("========== PRODUTOS COM ESTOQUE BAIXO ==========");

        produtos.values()
                .stream()
                .filter(produto -> produto.getEstoque() <= limite)
                .forEach(Produto::exibir);

        System.out.println();
    }

    private Produto buscarProdutoObrigatorio(String sku) {
        return Optional.ofNullable(produtos.get(sku))
                .orElseThrow(() -> new IllegalArgumentException("Produto não encontrado para o SKU: " + sku));
    }

    private Cliente buscarClienteObrigatorio(int clienteId) {
        return Optional.ofNullable(clientes.get(clienteId))
                .orElseThrow(() -> new IllegalArgumentException("Cliente não encontrado para o ID: " + clienteId));
    }

    private Pedido buscarPedidoObrigatorio(int pedidoId) {
        return Optional.ofNullable(pedidos.get(pedidoId))
                .orElseThrow(() -> new IllegalArgumentException("Pedido não encontrado para o ID: " + pedidoId));
    }
}