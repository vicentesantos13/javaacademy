package atividade10;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class PrincipalAtividade10 {

    private static Scanner scanner = new Scanner(System.in);
    private static EcommerceService service = new EcommerceService();

    public static void main(String[] args) {
        int opcao;

        carregarDadosIniciais();

        do {
            exibirMenu();

            System.out.print("Escolha uma opção: ");
            opcao = Integer.parseInt(scanner.nextLine());

            try {
                switch (opcao) {
                    case 1 -> adicionarProduto();
                    case 2 -> service.listarProdutosPorSku();
                    case 3 -> service.listarProdutosPorPreco();
                    case 4 -> buscarProdutoPorSku();
                    case 5 -> adicionarCliente();
                    case 6 -> service.listarClientes();
                    case 7 -> criarPedido();
                    case 8 -> reservarEstoque();
                    case 9 -> aplicarDesconto();
                    case 10 -> pagarPedido();
                    case 11 -> cancelarPedido();
                    case 12 -> service.listarPedidos();
                    case 13 -> exibirRelatorios();
                    case 0 -> System.out.println("Sistema encerrado.");
                    default -> System.out.println("Opção inválida.");
                }
            } catch (IllegalArgumentException erro) {
                System.out.println("Operação não realizada.");
                System.out.println("Motivo: " + erro.getMessage());
                System.out.println();
            } catch (Exception erro) {
                System.out.println("Erro inesperado: " + erro.getMessage());
                System.out.println();
            }

        } while (opcao != 0);

        scanner.close();
    }

    private static void exibirMenu() {
        System.out.println("========== SIMULADOR DE PEDIDOS ==========");
        System.out.println("1  - Adicionar produto");
        System.out.println("2  - Listar produtos por SKU");
        System.out.println("3  - Listar produtos por preço");
        System.out.println("4  - Buscar produto por SKU");
        System.out.println("5  - Adicionar cliente");
        System.out.println("6  - Listar clientes");
        System.out.println("7  - Criar pedido");
        System.out.println("8  - Reservar estoque do pedido");
        System.out.println("9  - Aplicar desconto no pedido");
        System.out.println("10 - Pagar pedido");
        System.out.println("11 - Cancelar pedido");
        System.out.println("12 - Listar pedidos");
        System.out.println("13 - Gerar relatórios");
        System.out.println("0  - Sair");
        System.out.println();
    }

    private static void adicionarProduto() {
        System.out.print("SKU: ");
        String sku = scanner.nextLine();

        System.out.print("Nome: ");
        String nome = scanner.nextLine();

        System.out.print("Categoria: ");
        String categoria = scanner.nextLine();

        System.out.print("Preço: ");
        double preco = Double.parseDouble(scanner.nextLine());

        System.out.print("Estoque: ");
        int estoque = Integer.parseInt(scanner.nextLine());

        service.adicionarProduto(sku, nome, categoria, preco, estoque);
    }

    private static void buscarProdutoPorSku() {
        System.out.print("Digite o SKU do produto: ");
        String sku = scanner.nextLine();

        service.buscarProdutoPorSku(sku);
    }

    private static void adicionarCliente() {
        System.out.print("Nome do cliente: ");
        String nome = scanner.nextLine();

        System.out.print("Email do cliente: ");
        String email = scanner.nextLine();

        service.adicionarCliente(nome, email);
    }

    private static void criarPedido() {
        System.out.print("ID do cliente: ");
        int clienteId = Integer.parseInt(scanner.nextLine());

        Map<String, Integer> itens = new HashMap<>();

        String continuar;

        do {
            System.out.print("SKU do produto: ");
            String sku = scanner.nextLine();

            System.out.print("Quantidade: ");
            int quantidade = Integer.parseInt(scanner.nextLine());

            itens.put(sku, quantidade);

            System.out.print("Deseja adicionar outro item? (S/N): ");
            continuar = scanner.nextLine();

        } while (continuar.equalsIgnoreCase("S"));

        int pedidoId = service.criarPedido(clienteId, itens);

        System.out.println("Pedido criado com ID: " + pedidoId);
        System.out.println();
    }

    private static void reservarEstoque() {
        System.out.print("ID do pedido: ");
        int pedidoId = Integer.parseInt(scanner.nextLine());

        service.reservarEstoque(pedidoId);
    }

    private static void aplicarDesconto() {
        System.out.print("ID do pedido: ");
        int pedidoId = Integer.parseInt(scanner.nextLine());

        System.out.print("Percentual de desconto: ");
        double desconto = Double.parseDouble(scanner.nextLine());

        service.aplicarDesconto(pedidoId, desconto);
    }

    private static void pagarPedido() {
        System.out.print("ID do pedido: ");
        int pedidoId = Integer.parseInt(scanner.nextLine());

        System.out.print("Pagamento aprovado? (S/N): ");
        String resposta = scanner.nextLine();

        boolean pagamentoAprovado = resposta.equalsIgnoreCase("S");

        service.pagarPedido(pedidoId, pagamentoAprovado);
    }

    private static void cancelarPedido() {
        System.out.print("ID do pedido: ");
        int pedidoId = Integer.parseInt(scanner.nextLine());

        service.cancelarPedido(pedidoId);
    }

    private static void exibirRelatorios() {
        service.relatorioFaturamentoTotal();
        service.relatorioTopProdutosVendidos();
        service.relatorioFaturamentoPorCategoria();
        service.relatorioClientesComMaisPedidos();

        System.out.print("Digite o limite para considerar estoque baixo: ");
        int limite = Integer.parseInt(scanner.nextLine());

        service.relatorioProdutosComEstoqueBaixo(limite);
    }

    private static void carregarDadosIniciais() {
        service.adicionarProduto("P001", "Notebook", "Eletrônicos", 3500.00, 10);
        service.adicionarProduto("P002", "Mouse", "Eletrônicos", 80.00, 30);
        service.adicionarProduto("P003", "Camiseta", "Vestuário", 60.00, 20);
        service.adicionarProduto("P004", "Tênis", "Vestuário", 250.00, 8);

        service.adicionarCliente("João Silva", "joao@email.com");
        service.adicionarCliente("Maria Souza", "maria@email.com");

        System.out.println("Dados iniciais carregados com sucesso.");
        System.out.println();
    }
}