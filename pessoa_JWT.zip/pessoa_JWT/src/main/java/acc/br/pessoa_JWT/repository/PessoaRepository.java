package acc.br.pessoa_JWT.repository;

import acc.br.pessoa_JWT.entity.Pessoa;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PessoaRepository extends JpaRepository<Pessoa, Long> {
}