package acc.br.pessoa_JWT.controller;


import acc.br.pessoa_JWT.entity.Pessoa;
import  acc.br.pessoa_JWT.service.PessoaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pessoas")
public class PessoaController {

    private final PessoaService service;

    public PessoaController(PessoaService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<List<Pessoa>> getAllPessoas() {
        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Pessoa> getPessoaById(@PathVariable Long id) {
        return ResponseEntity.ok(service.findById(id));
    }

    @PostMapping
    public ResponseEntity<Pessoa> createPessoa(@RequestBody Pessoa pessoa) {
        return ResponseEntity.ok(service.save(pessoa));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Pessoa> updatePessoa(
            @PathVariable Long id,
            @RequestBody Pessoa pessoaDetails
    ) {
        return ResponseEntity.ok(service.update(id, pessoaDetails));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePessoa(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}