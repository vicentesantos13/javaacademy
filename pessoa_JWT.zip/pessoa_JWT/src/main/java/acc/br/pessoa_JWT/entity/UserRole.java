package acc.br.pessoa_JWT.entity;

public enum UserRole {
    ADMIN,
    USER
}