package acc.br.pessoa_JWT.dto;

public record LoginResponseDTO(String token) {
}