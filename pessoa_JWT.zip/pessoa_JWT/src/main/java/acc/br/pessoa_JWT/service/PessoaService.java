package acc.br.pessoa_JWT.service;


import acc.br.pessoa_JWT.entity.Pessoa;
import acc.br.pessoa_JWT.repository.PessoaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PessoaService {

    private final PessoaRepository repository;

    public PessoaService(PessoaRepository repository) {
        this.repository = repository;
    }

    @Transactional(readOnly = true)
    public List<Pessoa> findAll() {
        return repository.findAll();
    }

    @Transactional(readOnly = true)
    public Pessoa findById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pessoa não encontrada com ID: " + id));
    }

    @Transactional
    public Pessoa save(Pessoa pessoa) {
        return repository.save(pessoa);
    }

    @Transactional
    public Pessoa update(Long id, Pessoa pessoaDetails) {
        Pessoa pessoa = findById(id);
        pessoa.setNome(pessoaDetails.getNome());
        return repository.save(pessoa);
    }

    @Transactional
    public void delete(Long id) {
        Pessoa pessoa = findById(id);
        repository.delete(pessoa);
    }
}